---
title: "Soirée ADULTES dans la foi: "
date: 2025-08-08T17:30:19.856Z
image: /images/uploads/film-sacerdoce.png
location: Salle de la Closière, 3 rue Sainte-Anne 1420 Braine-l'Alleud
description: Rencontre pour les adultes qui désirent approfondir et re-découvrir
  la Foi autour d'un verre, de partages et de prières.
---
