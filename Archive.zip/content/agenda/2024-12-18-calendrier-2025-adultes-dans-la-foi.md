---
title: "Calendrier 2025 Adultes dans la Foi "
date: 2025-05-16T10:13:07.028Z
image: /images/uploads/trimestrielle-225.png
location: La Closière (Salle Paroissiale) Rue Sainte-Anne, 3 1420 Braine-L'Alleud
description: Les soirées "Adultes dans la Foi" de l'Unité Pastorale de
  Braine-l'Alleud offrent aux adultes un espace pour redécouvrir et approfondir
  leur foi. Ces rencontres sont l'occasion de partager des moments de réflexion
  et d'échange dans un cadre convivial.
---
