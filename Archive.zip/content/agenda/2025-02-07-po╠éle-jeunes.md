---
title: Soirée Jeunes
date: 2025-06-20T16:30:10.365Z
image: /images/uploads/250520.jpeg
location: Salle de la Closière, 3 rue Sainte-Anne 1420 Braine-l'Alleud.
description: Entretien de la foi autour d'une collation, de partages et de prières.
---
