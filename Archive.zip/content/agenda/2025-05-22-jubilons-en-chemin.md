---
title: Jubilons en Chemin
date: 2025-06-09T04:00:32.705Z
image: /images/uploads/affiche-25.png
location: Départ Eglise Saint-Sébastien
description: >-
  Comme chaque année, notre paroisse se met en marche pour le traditionnel
  pèlerinage des églises de Braine-l’Alleud.

  Mais cette fois, notre marche prend une dimension toute particulière : en cette année du Jubilé 2025, proclamée par le pape François sous le beau thème « Peregrinantes in spem » – Pèlerins de l’espérance.


  Ce Jubilé ordinaire, qui succède à celui de l’an 2000 et au Jubilé de la Miséricorde de 2016, est une invitation à vivre une année de conversion, de pardon, de joie et d’action de grâce, dans une Église en marche… pleine d’espérance !


  🙏 Rejoignez-nous dans cette démarche spirituelle, symbolique et fraternelle.

  Qu’ensemble, nous soyons des pèlerins de l’Espérance en route vers 2025 !
---
