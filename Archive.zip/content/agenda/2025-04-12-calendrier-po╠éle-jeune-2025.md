---
title: Calendrier Pôle Jeune 2025
date: 2025-04-12T08:10:14.554Z
image: /images/uploads/unité_pastorale_de_braine_l‘alleud_-9-.png
location: La Closière (Salle Paroissiale) Rue Sainte-Anne, 3 1420 Braine-L'Alleud
description: Les soirées "Adultes dans la Foi" de l'Unité Pastorale de
  Braine-l'Alleud offrent aux adultes un espace pour redécouvrir et approfondir
  leur foi. Ces rencontres sont l'occasion de partager des moments de réflexion
  et d'échange dans un cadre convivial.
---
