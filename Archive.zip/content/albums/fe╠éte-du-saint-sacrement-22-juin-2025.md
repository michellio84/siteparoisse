---
title: Fête du Saint Sacrement 22 Juin 2025
date: 2025-06-23T08:10:24.066Z
link: https://photos.app.goo.gl/23ktsFxaGR7cyZmj7
cover: /images/uploads/img_4298.jpeg
---
