---
title: Retraite des enfants du KT 2025
date: 2025-05-27T08:36:42.608Z
link: https://photos.app.goo.gl/PYRvHj8aWBnw4SAC9
cover: /images/uploads/whatsapp-image-2025-05-27-at-15.14.33-1-.jpeg
---
