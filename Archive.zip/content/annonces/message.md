---
message: Vendredi 8 Août à 19h30, projection du film "Sacerdoce". Durant l'été,
  pas d'Eucharistie le mercredi soir. Nouvelle fonction du site, l'onglet
  Galerie du menu, vous permet d'accéder aux albums photos
---
