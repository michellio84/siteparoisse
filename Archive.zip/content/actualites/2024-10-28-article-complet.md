---
title: Introduction du nouveau site de la paroisse
date: 2024-11-02T13:33:16.803Z
description: "Actualités "
---
**Chers paroissiens,**

C'est avec une grande joie que je vous annonce le lancement de notre nouveau site web de la paroisse ! Nous avons souhaité créer un espace accessible, chaleureux et vivant, où chacun pourra trouver des informations pratiques, découvrir nos activités et se sentir partie intégrante de notre communauté.

Sur ce site, vous pourrez consulter les horaires des messes, les événements à venir, et retrouver des ressources spirituelles pour nourrir votre foi au quotidien. Nous espérons que cet outil facilitera la communication entre nous et vous permettra de rester connectés avec la vie de la paroisse, même à distance.

Ce site a été conçu pour vous et nous espérons qu'il répondra à vos attentes. N’hésitez pas à le parcourir, à nous faire part de vos impressions, et surtout, à le partager autour de vous !

Dans la foi et l’amitié,

**Nicolas Favart, Curé de la Paroisse**