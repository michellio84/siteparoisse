---
title: 9 Juin pèlerinage jubilaire du lundi de Pentecôte
date: 2025-05-30T08:54:06.120Z
description: Pèlerinage
---
# H﻿oraire du pèlerinage du lundi de Pentecôte

* 6﻿h00 : Départ de l'église Saint-Sébastien
* 7﻿h30 : Laudes et petit-déjeuner à l'église Sainte-Aldegonde à Ophain
* 8﻿h35 : Prière à la chapelle Notre-Dame des Belles-Pierres
* 1﻿0h30 : Eucharistie à Bois-Seigneur-Isaac
* 1﻿7h00-17h30 : Arrivée à la collégiale Sainte-Gertrude de Nivelles et démarche jubilaire.

Rejoignez-nous à tout moment de la journée pour une étape ou plus si le cœur vous en dit.  Pour marcher ou prier dans une des églises, pour l’Eucharistie ou la démarche jubilaire à la collégiale Sainte-Gertrude de Nivelles, … 
Les heures d’arrivée sont approximatives.
À prévoir : pique-nique pour midi.